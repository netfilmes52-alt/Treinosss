package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ModernBottomBar
import com.example.ui.components.PRBadge
import com.example.ui.components.RestTimerBar
import com.example.ui.components.UndoSnackbar
import com.example.ui.screens.CalendarHistoryScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ExercisesScreen
import com.example.ui.screens.GeminiCoachScreen
import com.example.ui.screens.SettingsBackupScreen
import com.example.ui.screens.WorkoutSessionScreen
import com.example.ui.theme.FitLogTheme
import com.example.ui.viewmodel.FitLogViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: FitLogViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
            val categories by viewModel.allCategories.collectAsStateWithLifecycle()
            val exercises by viewModel.allExercises.collectAsStateWithLifecycle()
            val sessions by viewModel.allSessions.collectAsStateWithLifecycle()

            val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
            val isGeminiLoading by viewModel.isGeminiLoading.collectAsStateWithLifecycle()

            val restSeconds by viewModel.restTimerSeconds.collectAsStateWithLifecycle()
            val restInitialSeconds by viewModel.restTimerInitialSeconds.collectAsStateWithLifecycle()
            val isTimerRunning by viewModel.isRestTimerRunning.collectAsStateWithLifecycle()
            val timerFinishedEvent by viewModel.restTimerFinishedEvent.collectAsStateWithLifecycle()

            val prNotification by viewModel.latestPRNotification.collectAsStateWithLifecycle()
            val undoMessage by viewModel.undoMessage.collectAsStateWithLifecycle()

            val context = LocalContext.current

            LaunchedEffect(timerFinishedEvent) {
                if (timerFinishedEvent) {
                    Toast.makeText(context, "⏰ TEMPO DE DESCANSO CONCLUÍDO! Hora do próximo set!", Toast.LENGTH_LONG).show()
                    viewModel.dismissTimerFinishedEvent()
                }
            }

            FitLogTheme(darkTheme = isDarkMode) {
                var currentTab by remember { mutableStateOf(0) }
                var workoutInitialExerciseId by remember { mutableStateOf<Long?>(null) }

                val snackbarHostState = remember { SnackbarHostState() }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    bottomBar = {
                        Column {
                            // Floating Rest Timer Bar right above Navigation Bar
                            RestTimerBar(
                                secondsRemaining = restSeconds,
                                initialSeconds = restInitialSeconds,
                                isRunning = isTimerRunning,
                                onPauseResume = {
                                    if (isTimerRunning) viewModel.pauseRestTimer() else viewModel.resumeRestTimer()
                                },
                                onAdd30Seconds = { viewModel.addRestTime(30) },
                                onClose = { viewModel.stopRestTimer() }
                            )

                            // Modern Floating Dock Bottom Bar
                            ModernBottomBar(
                                currentTab = currentTab,
                                onTabSelected = { selected -> currentTab = selected },
                                onStartWorkoutClick = {
                                    workoutInitialExerciseId = null
                                    currentTab = 3
                                }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            0 -> DashboardScreen(
                                exercises = exercises,
                                sessions = sessions,
                                onStartWorkoutClick = { exId ->
                                    workoutInitialExerciseId = exId
                                    currentTab = 3
                                },
                                onExerciseClick = { exId ->
                                    workoutInitialExerciseId = exId
                                    currentTab = 3
                                },
                                onOpenGeminiCoach = {
                                    currentTab = 1
                                },
                                onOpenSettings = {
                                    currentTab = 5
                                }
                            )

                            1 -> GeminiCoachScreen(
                                messages = chatMessages,
                                isLoading = isGeminiLoading,
                                onSendMessage = { text -> viewModel.sendGeminiQuery(text) },
                                onAnalyzeProgress = { viewModel.analyzeProgressWithGemini() },
                                onClearChat = { viewModel.clearChatHistory() }
                            )

                            2 -> ExercisesScreen(
                                categories = categories,
                                exercises = exercises,
                                sessions = sessions,
                                onStartWorkoutForExercise = { exId ->
                                    workoutInitialExerciseId = exId
                                    currentTab = 3
                                },
                                onAddCategory = { name, colorHex ->
                                    viewModel.addCategory(name, colorHex, "fitness_center")
                                },
                                onUpdateCategory = { cat -> viewModel.updateCategory(cat) },
                                onDeleteCategoryWithMove = { cat, targetId ->
                                    viewModel.deleteCategory(cat, targetId)
                                },
                                onAddExercise = { catId, name, target ->
                                    viewModel.addExercise(catId, name, target)
                                },
                                onUpdateExercise = { ex -> viewModel.updateExercise(ex) },
                                onDuplicateExercise = { ex -> viewModel.duplicateExercise(ex) },
                                onDeleteExercise = { ex -> viewModel.deleteExercise(ex) },
                                onRequestSessionsCount = { exId, callback ->
                                    viewModel.getSessionsCountForExercise(exId, callback)
                                }
                            )

                            3 -> WorkoutSessionScreen(
                                exercises = exercises,
                                sessions = sessions,
                                initialExerciseId = workoutInitialExerciseId,
                                onSaveSession = { exId, exName, ts, notes, tags, sets, autoTimer, restSecs ->
                                    viewModel.saveWorkoutSession(
                                        exerciseId = exId,
                                        exerciseName = exName,
                                        timestamp = ts,
                                        notes = notes,
                                        tags = tags,
                                        sets = sets,
                                        autoStartTimer = autoTimer,
                                        restSeconds = restSecs
                                    )
                                    Toast.makeText(context, "Treino registrado com sucesso!", Toast.LENGTH_SHORT).show()
                                    currentTab = 0
                                }
                            )

                            4 -> CalendarHistoryScreen(
                                sessions = sessions,
                                exercises = exercises,
                                onUpdateSession = { sId, exId, ts, notes, tags, sets ->
                                    viewModel.updateSessionAndSets(sId, exId, ts, notes, tags, sets)
                                },
                                onDuplicateSession = { sDetails ->
                                    viewModel.duplicateSession(sDetails)
                                    Toast.makeText(context, "Treino duplicado com sucesso!", Toast.LENGTH_SHORT).show()
                                },
                                onDeleteSession = { sDetails ->
                                    viewModel.deleteSession(sDetails)
                                }
                            )

                            5 -> SettingsBackupScreen(
                                isDarkMode = isDarkMode,
                                onToggleDarkMode = { viewModel.toggleDarkMode() },
                                onExportBackup = { callback -> viewModel.exportBackup(callback) },
                                onImportBackup = { json, callback -> viewModel.importBackup(json, callback) }
                            )
                        }

                        // Undo Snackbar Overlay at bottom
                        UndoSnackbar(
                            message = undoMessage,
                            onUndo = { viewModel.undoLastDeletion() },
                            onDismiss = { viewModel.dismissUndoMessage() },
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )

                        // PR Celebration Dialog
                        prNotification?.let { msg ->
                            AlertDialog(
                                onDismissRequest = { viewModel.dismissPRNotification() },
                                title = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        PRBadge(label = "NOVO RECORDE!")
                                    }
                                },
                                text = {
                                    Text(
                                        text = msg,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                                    )
                                },
                                confirmButton = {
                                    Button(onClick = { viewModel.dismissPRNotification() }) {
                                        Text("Incrível! 🎉")
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
