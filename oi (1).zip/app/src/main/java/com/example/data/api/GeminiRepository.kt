package com.example.data.api

import com.example.BuildConfig
import com.example.data.models.ExerciseWithCategory
import com.example.data.models.SessionWithDetails
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateFitnessAdvice(
        prompt: String,
        userContext: String? = null
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Chave de API do Gemini não configurada. Configure sua GEMINI_API_KEY nas variáveis de ambiente do AI Studio para ativar o Assistente com IA."
        }

        val systemInstructionText = """
            Você é o Gemini Coach, um assistente especialista em musculação, educação física, nutrição esportiva e treinamento de força.
            Sua missão é ajudar o usuário com dicas práticas, correções de postura/execução, sugestões de séries/repetições, nutrição e análise de desempenho.
            Seja motivador, conciso, estruturado (use tópicos ou marcadores quando apropriado) e fale em Português do Brasil de forma clara e amigável.
            ${userContext?.let { "Contexto do usuário no app FitLog: $it" } ?: ""}
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", systemInstructionText))
                })
            })
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", prompt))
                    })
                })
            })
        }

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
            .post(jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    val errObj = try { JSONObject(responseStr) } catch (e: Exception) { null }
                    val errMsg = errObj?.optJSONObject("error")?.optString("message") ?: "Erro (${response.code})"
                    return@withContext "Erro ao consultar o Gemini Coach: $errMsg"
                }

                val jsonResp = JSONObject(responseStr)
                val candidates = jsonResp.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text", "Sem resposta gerada.")
                    }
                }
                "Não foi possível obter a resposta do Gemini no momento."
            }
        } catch (e: Exception) {
            "Falha na conexão com o Gemini API: ${e.localizedMessage ?: e.message}"
        }
    }

    suspend fun analyzeProgressAndSuggest(
        exercises: List<ExerciseWithCategory>,
        sessions: List<SessionWithDetails>
    ): String = withContext(Dispatchers.IO) {
        val summaryBuilder = StringBuilder()
        summaryBuilder.append("O usuário possui ${exercises.size} exercícios cadastrados no catálogo.\n")
        summaryBuilder.append("Total de sessões de treino registradas: ${sessions.size}.\n\n")

        val recentSessions = sessions.sortedByDescending { it.session.timestamp }.take(10)
        if (recentSessions.isNotEmpty()) {
            summaryBuilder.append("Últimos treinos registrados:\n")
            recentSessions.forEach { sDetails ->
                val maxW = sDetails.sets.maxOfOrNull { it.weightKg } ?: 0f
                summaryBuilder.append("- ${sDetails.exercise.name}: Máxima de ${maxW}kg em ${sDetails.sets.size} séries.\n")
            }
        }

        val prompt = "Com base no meu histórico de treinos recente acima, faça uma análise rápida do meu progresso e forneça 3 dicas práticas para eu continuar evoluindo em cargas e hipertrofia."
        generateFitnessAdvice(prompt, summaryBuilder.toString())
    }
}
