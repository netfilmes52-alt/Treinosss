package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.models.CategoryEntity
import com.example.data.models.ExerciseEntity
import com.example.data.models.ExerciseSetEntity
import com.example.data.models.ExerciseWithCategory
import com.example.data.models.SessionWithDetails
import com.example.data.models.WorkoutSessionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FitLogDao {

    // --- CATEGORIES ---
    @Query("SELECT * FROM categories ORDER BY name ASC")
    fun getAllCategories(): Flow<List<CategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: CategoryEntity): Long

    @Update
    suspend fun updateCategory(category: CategoryEntity)

    @Delete
    suspend fun deleteCategory(category: CategoryEntity)

    @Query("UPDATE exercises SET categoryId = :toCategoryId WHERE categoryId = :fromCategoryId")
    suspend fun moveExercisesToCategory(fromCategoryId: Long, toCategoryId: Long)

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun getCategoryCount(): Int

    // --- EXERCISES ---
    @Transaction
    @Query("SELECT * FROM exercises ORDER BY name ASC")
    fun getAllExercisesWithCategory(): Flow<List<ExerciseWithCategory>>

    @Transaction
    @Query("SELECT * FROM exercises WHERE categoryId = :categoryId ORDER BY name ASC")
    fun getExercisesByCategory(categoryId: Long): Flow<List<ExerciseWithCategory>>

    @Query("SELECT * FROM exercises WHERE id = :id LIMIT 1")
    suspend fun getExerciseById(id: Long): ExerciseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercise(exercise: ExerciseEntity): Long

    @Update
    suspend fun updateExercise(exercise: ExerciseEntity)

    @Delete
    suspend fun deleteExercise(exercise: ExerciseEntity)

    @Query("SELECT COUNT(*) FROM workout_sessions WHERE exerciseId = :exerciseId")
    suspend fun getSessionsCountForExercise(exerciseId: Long): Int

    // --- SESSIONS ---
    @Transaction
    @Query("SELECT * FROM workout_sessions ORDER BY timestamp DESC")
    fun getAllSessionsWithDetails(): Flow<List<SessionWithDetails>>

    @Transaction
    @Query("SELECT * FROM workout_sessions WHERE exerciseId = :exerciseId ORDER BY timestamp DESC")
    fun getSessionsForExercise(exerciseId: Long): Flow<List<SessionWithDetails>>

    @Transaction
    @Query("SELECT * FROM workout_sessions WHERE exerciseId = :exerciseId ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLastSessionForExercise(exerciseId: Long): SessionWithDetails?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: WorkoutSessionEntity): Long

    @Update
    suspend fun updateSession(session: WorkoutSessionEntity)

    @Delete
    suspend fun deleteSession(session: WorkoutSessionEntity)

    // --- SETS ---
    @Query("SELECT * FROM exercise_sets WHERE sessionId = :sessionId ORDER BY setNumber ASC")
    fun getSetsForSession(sessionId: Long): Flow<List<ExerciseSetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSet(set: ExerciseSetEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSets(sets: List<ExerciseSetEntity>)

    @Query("DELETE FROM exercise_sets WHERE sessionId = :sessionId")
    suspend fun deleteSetsForSession(sessionId: Long)

    @Query("DELETE FROM exercise_sets WHERE id = :setId")
    suspend fun deleteSetById(setId: Long)

    @Query("SELECT MAX(weightKg) FROM exercise_sets INNER JOIN workout_sessions ON exercise_sets.sessionId = workout_sessions.id WHERE workout_sessions.exerciseId = :exerciseId")
    suspend fun getMaxWeightForExercise(exerciseId: Long): Float?

    // Clean all data (for backup restore)
    @Query("DELETE FROM categories")
    suspend fun deleteAllCategories()

    @Query("DELETE FROM exercises")
    suspend fun deleteAllExercises()

    @Query("DELETE FROM workout_sessions")
    suspend fun deleteAllSessions()

    @Query("DELETE FROM exercise_sets")
    suspend fun deleteAllSets()
}
