package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.FitLogDao
import com.example.data.models.CategoryEntity
import com.example.data.models.ExerciseEntity
import com.example.data.models.ExerciseSetEntity
import com.example.data.models.WorkoutSessionEntity

@Database(
    entities = [
        CategoryEntity::class,
        ExerciseEntity::class,
        WorkoutSessionEntity::class,
        ExerciseSetEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class FitLogDatabase : RoomDatabase() {

    abstract fun fitLogDao(): FitLogDao

    companion object {
        @Volatile
        private var INSTANCE: FitLogDatabase? = null

        fun getDatabase(context: Context): FitLogDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FitLogDatabase::class.java,
                    "fitlog_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
