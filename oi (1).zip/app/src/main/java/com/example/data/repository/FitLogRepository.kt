package com.example.data.repository

import com.example.data.dao.FitLogDao
import com.example.data.models.CategoryEntity
import com.example.data.models.ExerciseEntity
import com.example.data.models.ExerciseSetEntity
import com.example.data.models.ExerciseWithCategory
import com.example.data.models.SessionWithDetails
import com.example.data.models.WorkoutSessionEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

class FitLogRepository(private val dao: FitLogDao) {

    val allCategories: Flow<List<CategoryEntity>> = dao.getAllCategories()
    val allExercises: Flow<List<ExerciseWithCategory>> = dao.getAllExercisesWithCategory()
    val allSessions: Flow<List<SessionWithDetails>> = dao.getAllSessionsWithDetails()

    fun getSessionsForExercise(exerciseId: Long): Flow<List<SessionWithDetails>> =
        dao.getSessionsForExercise(exerciseId)

    suspend fun getLastSessionForExercise(exerciseId: Long): SessionWithDetails? =
        dao.getLastSessionForExercise(exerciseId)

    suspend fun seedInitialDataIfEmpty() {
        if (dao.getCategoryCount() == 0) {
            val pushId = dao.insertCategory(CategoryEntity(name = "Push", colorHex = "#FF5722", iconName = "fitness_center"))
            val pullId = dao.insertCategory(CategoryEntity(name = "Pull", colorHex = "#2196F3", iconName = "fitness_center"))
            val legsId = dao.insertCategory(CategoryEntity(name = "Legs", colorHex = "#4CAF50", iconName = "directions_run"))
            val upperId = dao.insertCategory(CategoryEntity(name = "Upper", colorHex = "#9C27B0", iconName = "fitness_center"))
            val lowerId = dao.insertCategory(CategoryEntity(name = "Lower", colorHex = "#FF9800", iconName = "directions_walk"))

            // Push exercises
            val ex1 = dao.insertExercise(ExerciseEntity(categoryId = pushId, name = "Supino Reto com Barra", targetMuscles = "Peitoral, Tríceps, Ombro Anterior"))
            val ex2 = dao.insertExercise(ExerciseEntity(categoryId = pushId, name = "Desenvolvimento com Halteres", targetMuscles = "Ombros, Tríceps"))
            val ex3 = dao.insertExercise(ExerciseEntity(categoryId = pushId, name = "Tríceps Pulley Corda", targetMuscles = "Tríceps"))
            val ex4 = dao.insertExercise(ExerciseEntity(categoryId = pushId, name = "Elevação Lateral", targetMuscles = "Ombro Lateral"))

            // Pull exercises
            val ex5 = dao.insertExercise(ExerciseEntity(categoryId = pullId, name = "Puxada Frontal", targetMuscles = "Dorsal, Bíceps"))
            val ex6 = dao.insertExercise(ExerciseEntity(categoryId = pullId, name = "Remada Curvada com Barra", targetMuscles = "Costas, Trtrapézio"))
            val ex7 = dao.insertExercise(ExerciseEntity(categoryId = pullId, name = "Rosca Direta com Barra W", targetMuscles = "Bíceps"))

            // Legs exercises
            val ex8 = dao.insertExercise(ExerciseEntity(categoryId = legsId, name = "Agachamento Livre com Barra", targetMuscles = "Quadríceps, Glúteos"))
            val ex9 = dao.insertExercise(ExerciseEntity(categoryId = legsId, name = "Leg Press 45°", targetMuscles = "Quadríceps, Glúteos"))
            val ex10 = dao.insertExercise(ExerciseEntity(categoryId = legsId, name = "Stiff com Halteres", targetMuscles = "Posterior de Coxa, Glúteos"))

            // Insert sample initial historical sessions so charts are populated nicely right away
            val now = System.currentTimeMillis()
            val dayMillis = 86400000L

            // Session 1: Supino Reto 7 days ago
            val s1 = dao.insertSession(WorkoutSessionEntity(exerciseId = ex1, timestamp = now - 7 * dayMillis, notes = "Treino pesado, boa execução", tags = "Bom treino", isPR = false))
            dao.insertSets(listOf(
                ExerciseSetEntity(sessionId = s1, setNumber = 1, weightKg = 60f, reps = 12),
                ExerciseSetEntity(sessionId = s1, setNumber = 2, weightKg = 70f, reps = 10),
                ExerciseSetEntity(sessionId = s1, setNumber = 3, weightKg = 75f, reps = 8)
            ))

            // Session 2: Supino Reto 3 days ago (PR!)
            val s2 = dao.insertSession(WorkoutSessionEntity(exerciseId = ex1, timestamp = now - 3 * dayMillis, notes = "Recorde batido no supino!", tags = "Bati PR, Gás total", isPR = true))
            dao.insertSets(listOf(
                ExerciseSetEntity(sessionId = s2, setNumber = 1, weightKg = 65f, reps = 12),
                ExerciseSetEntity(sessionId = s2, setNumber = 2, weightKg = 75f, reps = 10),
                ExerciseSetEntity(sessionId = s2, setNumber = 3, weightKg = 82.5f, reps = 6)
            ))

            // Session 3: Agachamento 2 days ago
            val s3 = dao.insertSession(WorkoutSessionEntity(exerciseId = ex8, timestamp = now - 2 * dayMillis, notes = "Foco em amplitude profunda", tags = "Bom treino", isPR = true))
            dao.insertSets(listOf(
                ExerciseSetEntity(sessionId = s3, setNumber = 1, weightKg = 80f, reps = 10),
                ExerciseSetEntity(sessionId = s3, setNumber = 2, weightKg = 90f, reps = 8),
                ExerciseSetEntity(sessionId = s3, setNumber = 3, weightKg = 100f, reps = 6)
            ))

            // Session 4: Puxada Frontal 1 day ago
            val s4 = dao.insertSession(WorkoutSessionEntity(exerciseId = ex5, timestamp = now - 1 * dayMillis, notes = "Contração de pico mantida", tags = "Gás total", isPR = false))
            dao.insertSets(listOf(
                ExerciseSetEntity(sessionId = s4, setNumber = 1, weightKg = 50f, reps = 12),
                ExerciseSetEntity(sessionId = s4, setNumber = 2, weightKg = 55f, reps = 10),
                ExerciseSetEntity(sessionId = s4, setNumber = 3, weightKg = 60f, reps = 8)
            ))
        }
    }

    suspend fun saveWorkoutSession(
        exerciseId: Long,
        timestamp: Long,
        notes: String,
        tags: String,
        sets: List<Pair<Float, Int>> // weight, reps
    ): Long {
        val maxPreviousWeight = dao.getMaxWeightForExercise(exerciseId) ?: 0f
        val currentMaxWeight = sets.maxOfOrNull { it.first } ?: 0f

        val isPR = currentMaxWeight > 0f && currentMaxWeight > maxPreviousWeight

        val sessionId = dao.insertSession(
            WorkoutSessionEntity(
                exerciseId = exerciseId,
                timestamp = timestamp,
                notes = notes,
                tags = tags,
                isPR = isPR
            )
        )

        val setEntities = sets.mapIndexed { index, (weight, reps) ->
            ExerciseSetEntity(
                sessionId = sessionId,
                setNumber = index + 1,
                weightKg = weight,
                reps = reps,
                isCompleted = true
            )
        }
        dao.insertSets(setEntities)
        return sessionId
    }

    // Category CRUD
    suspend fun insertCategory(category: CategoryEntity) = dao.insertCategory(category)
    suspend fun updateCategory(category: CategoryEntity) = dao.updateCategory(category)
    suspend fun deleteCategory(category: CategoryEntity) = dao.deleteCategory(category)
    suspend fun deleteCategoryAndMoveExercises(categoryToDelete: CategoryEntity, targetCategoryId: Long?) {
        if (targetCategoryId != null && targetCategoryId != categoryToDelete.id) {
            dao.moveExercisesToCategory(categoryToDelete.id, targetCategoryId)
        }
        dao.deleteCategory(categoryToDelete)
    }

    // Exercise CRUD
    suspend fun insertExercise(exercise: ExerciseEntity) = dao.insertExercise(exercise)
    suspend fun updateExercise(exercise: ExerciseEntity) = dao.updateExercise(exercise)
    suspend fun deleteExercise(exercise: ExerciseEntity) = dao.deleteExercise(exercise)
    suspend fun getSessionsCountForExercise(exerciseId: Long): Int = dao.getSessionsCountForExercise(exerciseId)
    suspend fun duplicateExercise(exercise: ExerciseEntity): Long {
        val copyName = if (exercise.name.contains("(Cópia)")) exercise.name else "${exercise.name} (Cópia)"
        return dao.insertExercise(
            ExerciseEntity(
                categoryId = exercise.categoryId,
                name = copyName,
                notes = exercise.notes,
                targetMuscles = exercise.targetMuscles
            )
        )
    }

    // Session CRUD
    suspend fun deleteSession(session: WorkoutSessionEntity) = dao.deleteSession(session)

    suspend fun updateSessionAndSets(
        sessionId: Long,
        exerciseId: Long,
        timestamp: Long,
        notes: String,
        tags: String,
        sets: List<Pair<Float, Int>>
    ) {
        val maxPreviousWeight = dao.getMaxWeightForExercise(exerciseId) ?: 0f
        val currentMaxWeight = sets.maxOfOrNull { it.first } ?: 0f
        val isPR = currentMaxWeight > 0f && currentMaxWeight >= maxPreviousWeight

        val updatedSession = WorkoutSessionEntity(
            id = sessionId,
            exerciseId = exerciseId,
            timestamp = timestamp,
            notes = notes,
            tags = tags,
            isPR = isPR
        )
        dao.updateSession(updatedSession)
        dao.deleteSetsForSession(sessionId)

        val setEntities = sets.mapIndexed { index, (weight, reps) ->
            ExerciseSetEntity(
                sessionId = sessionId,
                setNumber = index + 1,
                weightKg = weight,
                reps = reps,
                isCompleted = true
            )
        }
        dao.insertSets(setEntities)
    }

    suspend fun duplicateSession(sessionWithDetails: SessionWithDetails): Long {
        val setsData = sessionWithDetails.sets.map { Pair(it.weightKg, it.reps) }
        return saveWorkoutSession(
            exerciseId = sessionWithDetails.session.exerciseId,
            timestamp = System.currentTimeMillis(),
            notes = sessionWithDetails.session.notes,
            tags = sessionWithDetails.session.tags,
            sets = setsData
        )
    }

    suspend fun restoreSession(session: WorkoutSessionEntity, sets: List<ExerciseSetEntity>): Long {
        val newSessionId = dao.insertSession(session.copy(id = 0))
        val restoredSets = sets.map { it.copy(id = 0, sessionId = newSessionId) }
        dao.insertSets(restoredSets)
        return newSessionId
    }

    suspend fun restoreExercise(exercise: ExerciseEntity): Long {
        return dao.insertExercise(exercise.copy(id = 0))
    }

    suspend fun restoreCategory(category: CategoryEntity): Long {
        return dao.insertCategory(category.copy(id = 0))
    }

    // Backup Export JSON
    suspend fun exportToJson(): String {
        val categories = dao.getAllCategories().first()
        val exercises = dao.getAllExercisesWithCategory().first().map { it.exercise }
        val sessions = dao.getAllSessionsWithDetails().first()

        val root = JSONObject()
        root.put("version", 1)

        val categoriesArray = JSONArray()
        categories.forEach { c ->
            val cObj = JSONObject()
            cObj.put("id", c.id)
            cObj.put("name", c.name)
            cObj.put("colorHex", c.colorHex)
            cObj.put("iconName", c.iconName)
            categoriesArray.put(cObj)
        }
        root.put("categories", categoriesArray)

        val exercisesArray = JSONArray()
        exercises.forEach { e ->
            val eObj = JSONObject()
            eObj.put("id", e.id)
            eObj.put("categoryId", e.categoryId)
            eObj.put("name", e.name)
            eObj.put("notes", e.notes)
            eObj.put("targetMuscles", e.targetMuscles)
            exercisesArray.put(eObj)
        }
        root.put("exercises", exercisesArray)

        val sessionsArray = JSONArray()
        sessions.forEach { sDetails ->
            val s = sDetails.session
            val sObj = JSONObject()
            sObj.put("id", s.id)
            sObj.put("exerciseId", s.exerciseId)
            sObj.put("timestamp", s.timestamp)
            sObj.put("notes", s.notes)
            sObj.put("tags", s.tags)
            sObj.put("isPR", s.isPR)

            val setsArray = JSONArray()
            sDetails.sets.forEach { setItem ->
                val setObj = JSONObject()
                setObj.put("setNumber", setItem.setNumber)
                setObj.put("weightKg", setItem.weightKg)
                setObj.put("reps", setItem.reps)
                setsArray.put(setObj)
            }
            sObj.put("sets", setsArray)
            sessionsArray.put(sObj)
        }
        root.put("sessions", sessionsArray)

        return root.toString(2)
    }

    // Backup Import JSON
    suspend fun importFromJson(jsonString: String): Boolean {
        return try {
            val root = JSONObject(jsonString)

            dao.deleteAllSets()
            dao.deleteAllSessions()
            dao.deleteAllExercises()
            dao.deleteAllCategories()

            val categoryIdMap = mutableMapOf<Long, Long>()
            val exerciseIdMap = mutableMapOf<Long, Long>()

            if (root.has("categories")) {
                val catsArray = root.getJSONArray("categories")
                for (i in 0 until catsArray.length()) {
                    val cObj = catsArray.getJSONObject(i)
                    val oldId = cObj.getLong("id")
                    val name = cObj.getString("name")
                    val colorHex = cObj.optString("colorHex", "#FF5722")
                    val iconName = cObj.optString("iconName", "fitness_center")

                    val newId = dao.insertCategory(CategoryEntity(name = name, colorHex = colorHex, iconName = iconName))
                    categoryIdMap[oldId] = newId
                }
            }

            if (root.has("exercises")) {
                val exArray = root.getJSONArray("exercises")
                for (i in 0 until exArray.length()) {
                    val eObj = exArray.getJSONObject(i)
                    val oldId = eObj.getLong("id")
                    val oldCatId = eObj.getLong("categoryId")
                    val name = eObj.getString("name")
                    val notes = eObj.optString("notes", "")
                    val targetMuscles = eObj.optString("targetMuscles", "")

                    val newCatId = categoryIdMap[oldCatId] ?: categoryIdMap.values.firstOrNull() ?: 1L
                    val newId = dao.insertExercise(
                        ExerciseEntity(categoryId = newCatId, name = name, notes = notes, targetMuscles = targetMuscles)
                    )
                    exerciseIdMap[oldId] = newId
                }
            }

            if (root.has("sessions")) {
                val sessArray = root.getJSONArray("sessions")
                for (i in 0 until sessArray.length()) {
                    val sObj = sessArray.getJSONObject(i)
                    val oldExId = sObj.getLong("exerciseId")
                    val timestamp = sObj.getLong("timestamp")
                    val notes = sObj.optString("notes", "")
                    val tags = sObj.optString("tags", "")
                    val isPR = sObj.optBoolean("isPR", false)

                    val newExId = exerciseIdMap[oldExId] ?: continue

                    val newSessionId = dao.insertSession(
                        WorkoutSessionEntity(
                            exerciseId = newExId,
                            timestamp = timestamp,
                            notes = notes,
                            tags = tags,
                            isPR = isPR
                        )
                    )

                    if (sObj.has("sets")) {
                        val setsArray = sObj.getJSONArray("sets")
                        val setEntities = mutableListOf<ExerciseSetEntity>()
                        for (j in 0 until setsArray.length()) {
                            val setObj = setsArray.getJSONObject(j)
                            val setNum = setObj.getInt("setNumber")
                            val weight = setObj.getDouble("weightKg").toFloat()
                            val reps = setObj.getInt("reps")
                            setEntities.add(
                                ExerciseSetEntity(
                                    sessionId = newSessionId,
                                    setNumber = setNum,
                                    weightKg = weight,
                                    reps = reps,
                                    isCompleted = true
                                )
                            )
                        }
                        dao.insertSets(setEntities)
                    }
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
