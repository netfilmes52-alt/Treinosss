package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ChartDataPoint(
    val timestamp: Long,
    val value: Float,
    val label: String
)

@Composable
fun WeightEvolutionChart(
    dataPoints: List<ChartDataPoint>,
    modifier: Modifier = Modifier,
    lineColor: Color = MaterialTheme.colorScheme.primary
) {
    if (dataPoints.isEmpty()) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxWidth().height(180.dp)
            ) {
                Text(
                    text = "Sem registros de treino para este exercício ainda.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }
        }
        return
    }

    var selectedPoint by remember { mutableStateOf<ChartDataPoint?>(dataPoints.lastOrNull()) }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            selectedPoint?.let { pt ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "EVOLUÇÃO DE CARGA",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "${pt.value.toInt()} kg",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = lineColor
                        )
                    }
                    val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(pt.timestamp))
                    Text(
                        text = dateStr,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            val sortedPoints = remember(dataPoints) { dataPoints.sortedBy { it.timestamp } }
            val minVal = (sortedPoints.minOfOrNull { it.value } ?: 0f) * 0.85f
            val maxVal = (sortedPoints.maxOfOrNull { it.value } ?: 100f) * 1.15f
            val valRange = (maxVal - minVal).coerceAtLeast(1f)

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .pointerInput(sortedPoints) {
                        detectTapGestures { tapOffset ->
                            val width = size.width.toFloat()
                            val stepX = if (sortedPoints.size > 1) width / (sortedPoints.size - 1) else width
                            val closestIndex = (tapOffset.x / stepX).coerceIn(0f, (sortedPoints.size - 1).toFloat()).toInt()
                            selectedPoint = sortedPoints.getOrNull(closestIndex)
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val paddingBottom = 20.dp.toPx()
                val paddingTop = 10.dp.toPx()
                val usableHeight = canvasHeight - paddingBottom - paddingTop

                val stepX = if (sortedPoints.size > 1) canvasWidth / (sortedPoints.size - 1) else canvasWidth / 2

                val points = sortedPoints.mapIndexed { index, pt ->
                    val x = if (sortedPoints.size == 1) canvasWidth / 2 else index * stepX
                    val y = canvasHeight - paddingBottom - ((pt.value - minVal) / valRange * usableHeight)
                    Offset(x, y)
                }

                // Fill gradient path
                val path = Path()
                if (points.isNotEmpty()) {
                    path.moveTo(points.first().x, points.first().y)
                    for (i in 1 until points.size) {
                        val prev = points[i - 1]
                        val curr = points[i]
                        val control1 = Offset((prev.x + curr.x) / 2, prev.y)
                        val control2 = Offset((prev.x + curr.x) / 2, curr.y)
                        path.cubicTo(control1.x, control1.y, control2.x, control2.y, curr.x, curr.y)
                    }

                    val fillPath = Path().apply {
                        addPath(path)
                        lineTo(points.last().x, canvasHeight - paddingBottom)
                        lineTo(points.first().x, canvasHeight - paddingBottom)
                        close()
                    }

                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(lineColor.copy(alpha = 0.35f), Color.Transparent)
                        )
                    )

                    // Line stroke
                    drawPath(
                        path = path,
                        color = lineColor,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Draw circles
                    points.forEachIndexed { idx, pt ->
                        val isSelected = sortedPoints[idx] == selectedPoint
                        drawCircle(
                            color = if (isSelected) Color.White else lineColor,
                            radius = if (isSelected) 6.dp.toPx() else 4.dp.toPx(),
                            center = pt
                        )
                        drawCircle(
                            color = lineColor,
                            radius = if (isSelected) 6.dp.toPx() else 4.dp.toPx(),
                            center = pt,
                            style = Stroke(width = 2.dp.toPx())
                        )
                    }
                }
            }
        }
    }
}

data class CategoryVolumeData(
    val categoryName: String,
    val colorHex: String,
    val volumeKg: Float
)

@Composable
fun VolumeByCategoryChart(
    categoryVolumes: List<CategoryVolumeData>,
    modifier: Modifier = Modifier
) {
    if (categoryVolumes.isEmpty() || categoryVolumes.all { it.volumeKg <= 0f }) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = modifier
                .fillMaxWidth()
                .height(160.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxWidth().height(160.dp)
            ) {
                Text(
                    text = "Sem volume de treino registrado neste período.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }
        }
        return
    }

    val totalVolume = categoryVolumes.sumOf { it.volumeKg.toDouble() }.toFloat()

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "VOLUME POR GRUPO MUSCULAR",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                letterSpacing = 0.5.sp
            )
            Text(
                text = "${totalVolume.toInt()} kg total",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Horizontal volume bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(20.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
            ) {
                categoryVolumes.filter { it.volumeKg > 0 }.forEach { item ->
                    val weightFraction = item.volumeKg / totalVolume
                    val itemColor = try {
                        Color(android.graphics.Color.parseColor(item.colorHex))
                    } catch (e: Exception) {
                        MaterialTheme.colorScheme.primary
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth(weightFraction)
                            .height(20.dp)
                            .background(itemColor)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Legend
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categoryVolumes.filter { it.volumeKg > 0 }.forEach { item ->
                    val percentage = (item.volumeKg / totalVolume * 100).toInt()
                    val itemColor = try {
                        Color(android.graphics.Color.parseColor(item.colorHex))
                    } catch (e: Exception) {
                        MaterialTheme.colorScheme.primary
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .background(itemColor, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = item.categoryName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "${item.volumeKg.toInt()} kg ($percentage%)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }
    }
}
