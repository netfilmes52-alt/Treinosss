package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * Modern pill-shaped gradient progress bar component with smooth left-to-right filling
 * and continuous shimmer effect for indeterminate states.
 *
 * @param progress Float value from 0.0f to 1.0f for determinate progress, or null for indeterminate.
 * @param modifier Modifier for positioning and layout.
 * @param height Height of the progress bar track (default 8.dp).
 * @param showLabel If true, displays the animated percentage on top right.
 * @param trackColor Neutral translucent background track color.
 * @param gradientColors List of colors forming the fluid gradient fill.
 */
@Composable
fun ModernProgressBar(
    progress: Float?,
    modifier: Modifier = Modifier,
    height: Dp = 8.dp,
    showLabel: Boolean = false,
    trackColor: Color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    gradientColors: List<Color> = listOf(
        MaterialTheme.colorScheme.primary,
        MaterialTheme.colorScheme.tertiary
    )
) {
    val pillShape = RoundedCornerShape(percent = 50)

    Column(modifier = modifier.fillMaxWidth()) {
        if (showLabel && progress != null) {
            val percentage = (progress.coerceIn(0f, 1f) * 100).roundToInt()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$percentage%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(height)
                .clip(pillShape)
                .background(trackColor)
        ) {
            if (progress != null) {
                // Determinate animated smooth fill
                val coercedProgress = progress.coerceIn(0f, 1f)
                val animatedProgress by animateFloatAsState(
                    targetValue = coercedProgress,
                    animationSpec = tween(
                        durationMillis = 600,
                        easing = FastOutSlowInEasing
                    ),
                    label = "smoothProgressAnimation"
                )

                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(animatedProgress)
                        .clip(pillShape)
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = gradientColors
                            )
                        )
                )
            } else {
                // Indeterminate continuous shimmer glow
                val transition = rememberInfiniteTransition(label = "shimmerTransition")
                val translateAnim by transition.animateFloat(
                    initialValue = 0f,
                    targetValue = 1200f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(durationMillis = 1100, easing = LinearEasing),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "shimmerTranslate"
                )

                val shimmerColors = listOf(
                    gradientColors.first().copy(alpha = 0.25f),
                    gradientColors.first(),
                    if (gradientColors.size > 1) gradientColors[1] else gradientColors.first(),
                    gradientColors.first().copy(alpha = 0.25f)
                )

                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth()
                        .clip(pillShape)
                        .background(
                            brush = Brush.linearGradient(
                                colors = shimmerColors,
                                start = Offset(x = translateAnim - 600f, y = 0f),
                                end = Offset(x = translateAnim, y = 0f)
                            )
                        )
                )
            }
        }
    }
}
