package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ExerciseWithCategory
import com.example.data.models.SessionWithDetails
import com.example.ui.components.CalendarView
import com.example.ui.components.CategoryBadge
import com.example.ui.components.PRBadge
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class EditableSetEntry(
    var weightStr: String,
    var repsStr: String
)

@Composable
fun CalendarHistoryScreen(
    sessions: List<SessionWithDetails>,
    exercises: List<ExerciseWithCategory>,
    onUpdateSession: (Long, Long, Long, String, String, List<Pair<Float, Int>>) -> Unit,
    onDuplicateSession: (SessionWithDetails) -> Unit,
    onDeleteSession: (SessionWithDetails) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTimestamp by remember { mutableStateOf<Long?>(null) }
    var sessionToEdit by remember { mutableStateOf<SessionWithDetails?>(null) }
    var sessionToDelete by remember { mutableStateOf<SessionWithDetails?>(null) }

    val exerciseMap = remember(exercises) {
        exercises.associateBy { it.exercise.id }
    }

    val workoutTimestamps = remember(sessions) {
        sessions.map { it.session.timestamp }
    }

    val filteredSessions = remember(sessions, selectedTimestamp) {
        if (selectedTimestamp == null) {
            sessions.sortedByDescending { it.session.timestamp }
        } else {
            val calSelected = Calendar.getInstance().apply { timeInMillis = selectedTimestamp!! }
            sessions.filter { sDetails ->
                val sCal = Calendar.getInstance().apply { timeInMillis = sDetails.session.timestamp }
                sCal.get(Calendar.YEAR) == calSelected.get(Calendar.YEAR) &&
                        sCal.get(Calendar.DAY_OF_YEAR) == calSelected.get(Calendar.DAY_OF_YEAR)
            }.sortedByDescending { it.session.timestamp }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "CALENDÁRIO & HISTÓRICO",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )
            Text(
                text = "Seus Treinos",
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Calendar Component
        item {
            CalendarView(
                workoutTimestamps = workoutTimestamps,
                selectedTimestamp = selectedTimestamp,
                onDateSelected = { ts ->
                    selectedTimestamp = if (selectedTimestamp == ts) null else ts
                }
            )
        }

        // Selected Date Filter Indicator
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val labelText = if (selectedTimestamp != null) {
                    val dateFormatted = SimpleDateFormat("dd 'de' MMMM", Locale("pt", "BR")).format(Date(selectedTimestamp!!))
                    "Treinos em $dateFormatted (${filteredSessions.size})"
                } else {
                    "Todos os Treinos (${filteredSessions.size})"
                }

                Text(
                    text = labelText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                if (selectedTimestamp != null) {
                    OutlinedButton(
                        onClick = { selectedTimestamp = null },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Ver Todos", fontSize = 11.sp)
                    }
                }
            }
        }

        // History Feed Items
        if (filteredSessions.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Nenhum treino encontrado para esta data.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredSessions) { sDetails ->
                val exWithCat = exerciseMap[sDetails.session.exerciseId]
                HistoryCardItem(
                    sessionWithDetails = sDetails,
                    exerciseWithCategory = exWithCat,
                    onEdit = { sessionToEdit = sDetails },
                    onDuplicate = { onDuplicateSession(sDetails) },
                    onDelete = { sessionToDelete = sDetails }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // Edit Session Dialog
    sessionToEdit?.let { sDetails ->
        var notes by remember { mutableStateOf(sDetails.session.notes) }
        var tags by remember { mutableStateOf(sDetails.session.tags) }
        val setsList = remember {
            mutableStateListOf<EditableSetEntry>().apply {
                addAll(sDetails.sets.map { EditableSetEntry(it.weightKg.toInt().toString(), it.reps.toString()) })
            }
        }

        AlertDialog(
            onDismissRequest = { sessionToEdit = null },
            title = { Text("Editar Registro de Treino") },
            text = {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = sDetails.exercise.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Observações / Sensação") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = tags,
                            onValueChange = { tags = it },
                            label = { Text("Tags (ex: Bom treino, Gás total)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Séries Registradas:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { setsList.add(EditableSetEntry("20", "10")) }) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Série", fontSize = 12.sp)
                            }
                        }
                    }

                    items(setsList.size) { index ->
                        val entry = setsList[index]
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Série ${index + 1}:", fontSize = 12.sp, fontWeight = FontWeight.Bold)

                            OutlinedTextField(
                                value = entry.weightStr,
                                onValueChange = { entry.weightStr = it },
                                label = { Text("Kg") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )

                            OutlinedTextField(
                                value = entry.repsStr,
                                onValueChange = { entry.repsStr = it },
                                label = { Text("Reps") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )

                            if (setsList.size > 1) {
                                IconButton(
                                    onClick = { setsList.removeAt(index) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remover", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedSets = setsList.mapNotNull { e ->
                            val w = e.weightStr.toFloatOrNull() ?: return@mapNotNull null
                            val r = e.repsStr.toIntOrNull() ?: return@mapNotNull null
                            Pair(w, r)
                        }
                        if (parsedSets.isNotEmpty()) {
                            onUpdateSession(
                                sDetails.session.id,
                                sDetails.session.exerciseId,
                                sDetails.session.timestamp,
                                notes.trim(),
                                tags.trim(),
                                parsedSets
                            )
                            sessionToEdit = null
                        }
                    }
                ) {
                    Text("Salvar Alterações")
                }
            },
            dismissButton = {
                TextButton(onClick = { sessionToEdit = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Delete Session Confirmation Dialog
    sessionToDelete?.let { sDetails ->
        AlertDialog(
            onDismissRequest = { sessionToDelete = null },
            title = { Text("Excluir Registro de Treino?") },
            text = {
                Text(
                    text = "Tem certeza que deseja excluir o treino de '${sDetails.exercise.name}' realizado em ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(sDetails.session.timestamp))}?",
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteSession(sDetails)
                        sessionToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Excluir Treino")
                }
            },
            dismissButton = {
                TextButton(onClick = { sessionToDelete = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun HistoryCardItem(
    sessionWithDetails: SessionWithDetails,
    exerciseWithCategory: ExerciseWithCategory?,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    val dateStr = SimpleDateFormat("dd/MM/yyyy • HH:mm", Locale("pt", "BR")).format(Date(sessionWithDetails.session.timestamp))
    var menuExpanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = sessionWithDetails.exercise.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = dateStr,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (exerciseWithCategory != null) {
                        CategoryBadge(
                            name = exerciseWithCategory.category.name,
                            colorHex = exerciseWithCategory.category.colorHex
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    Box {
                        IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Opções do Treino",
                                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Editar Treino") },
                                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                onClick = {
                                    menuExpanded = false
                                    onEdit()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Duplicar Treino") },
                                leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                onClick = {
                                    menuExpanded = false
                                    onDuplicate()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Excluir Treino", color = MaterialTheme.colorScheme.error) },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp)) },
                                onClick = {
                                    menuExpanded = false
                                    onDelete()
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Breakdown of sets
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                sessionWithDetails.sets.forEach { setItem ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Série ${setItem.setNumber}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        Text(
                            text = "${setItem.weightKg.toInt()} kg  ×  ${setItem.reps} reps",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            if (sessionWithDetails.session.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Nota: ${sessionWithDetails.session.notes}",
                    fontSize = 12.sp,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
            }

            if (sessionWithDetails.session.isPR) {
                Spacer(modifier = Modifier.height(12.dp))
                PRBadge(label = "RECORDE PESSOAL")
            }
        }
    }
}
