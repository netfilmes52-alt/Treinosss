package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.CategoryEntity
import com.example.data.models.ExerciseEntity
import com.example.data.models.ExerciseWithCategory
import com.example.data.models.SessionWithDetails
import com.example.ui.components.CategoryBadge
import com.example.ui.components.ChartDataPoint
import com.example.ui.components.WeightEvolutionChart
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExercisesScreen(
    categories: List<CategoryEntity>,
    exercises: List<ExerciseWithCategory>,
    sessions: List<SessionWithDetails>,
    onStartWorkoutForExercise: (Long) -> Unit,
    onAddCategory: (String, String) -> Unit,
    onUpdateCategory: (CategoryEntity) -> Unit,
    onDeleteCategoryWithMove: (CategoryEntity, Long?) -> Unit,
    onAddExercise: (Long, String, String) -> Unit,
    onUpdateExercise: (ExerciseEntity) -> Unit,
    onDuplicateExercise: (ExerciseEntity) -> Unit,
    onDeleteExercise: (ExerciseEntity) -> Unit,
    onRequestSessionsCount: (Long, (Int) -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryId by remember { mutableStateOf<Long?>(null) }

    // Dialog & Sheet States
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var showManageCategoriesDialog by remember { mutableStateOf(false) }
    var editingCategory by remember { mutableStateOf<CategoryEntity?>(null) }
    var categoryToDelete by remember { mutableStateOf<CategoryEntity?>(null) }

    var showAddExerciseDialog by remember { mutableStateOf(false) }
    var editingExercise by remember { mutableStateOf<ExerciseEntity?>(null) }
    var exerciseToDeleteInfo by remember { mutableStateOf<Pair<ExerciseEntity, Int>?>(null) }
    var selectedExerciseForDetails by remember { mutableStateOf<ExerciseWithCategory?>(null) }

    val filteredExercises = remember(exercises, searchQuery, selectedCategoryId) {
        exercises.filter { ex ->
            val matchesCategory = selectedCategoryId == null || ex.exercise.categoryId == selectedCategoryId
            val matchesQuery = searchQuery.isBlank() ||
                    ex.exercise.name.contains(searchQuery, ignoreCase = true) ||
                    ex.exercise.targetMuscles.contains(searchQuery, ignoreCase = true) ||
                    ex.category.name.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }

    val colorPresets = remember {
        listOf("#FF5722", "#2196F3", "#4CAF50", "#9C27B0", "#FF9800", "#E91E63", "#00BCD4", "#795548", "#607D8B", "#FFC107")
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CATÁLOGO DE EXERCÍCIOS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Exercícios & Grupos",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(onClick = { showManageCategoriesDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Gerenciar Categorias",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Button(
                        onClick = { showAddCategoryDialog = true },
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("+ Categoria", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Search bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Buscar exercício ou músculo...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Buscar") },
                shape = RoundedCornerShape(20.dp),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Category Filter Chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                item {
                    FilterChip(
                        selected = selectedCategoryId == null,
                        onClick = { selectedCategoryId = null },
                        label = { Text("Todas (" + exercises.size + ")") },
                        shape = RoundedCornerShape(16.dp)
                    )
                }
                items(categories) { cat ->
                    val isSelected = cat.id == selectedCategoryId
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategoryId = if (isSelected) null else cat.id },
                        label = { Text(cat.name) },
                        shape = RoundedCornerShape(16.dp)
                    )
                }
            }
        }

        // Add Exercise Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filteredExercises.size} exercícios encontrados",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )

                Button(
                    onClick = { showAddExerciseDialog = true },
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Adicionar")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Novo Exercício", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Exercises List
        items(filteredExercises) { item ->
            val exSessions = sessions.filter { it.session.exerciseId == item.exercise.id }
            val maxWeight = exSessions.flatMap { it.sets }.maxOfOrNull { it.weightKg } ?: 0f
            val lastSession = exSessions.maxByOrNull { it.session.timestamp }

            ExerciseListItem(
                exerciseWithCategory = item,
                maxWeight = maxWeight,
                lastSessionDate = lastSession?.session?.timestamp,
                onClick = { selectedExerciseForDetails = item },
                onEdit = { editingExercise = item.exercise },
                onDuplicate = { onDuplicateExercise(item.exercise) },
                onDelete = {
                    onRequestSessionsCount(item.exercise.id) { count ->
                        exerciseToDeleteInfo = Pair(item.exercise, count)
                    }
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // Modal Sheet for Exercise Detail
    selectedExerciseForDetails?.let { item ->
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { selectedExerciseForDetails = null },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            val exSessions = sessions.filter { it.session.exerciseId == item.exercise.id }.sortedBy { it.session.timestamp }
            val prWeight = exSessions.flatMap { it.sets }.maxOfOrNull { it.weightKg } ?: 0f
            val lastSession = exSessions.lastOrNull()

            val chartPoints = exSessions.map { sDetails ->
                val maxW = sDetails.sets.maxOfOrNull { it.weightKg } ?: 0f
                ChartDataPoint(
                    timestamp = sDetails.session.timestamp,
                    value = maxW,
                    label = SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(sDetails.session.timestamp))
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.exercise.name,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (item.exercise.targetMuscles.isNotBlank()) {
                            Text(
                                text = "Músculos: ${item.exercise.targetMuscles}",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                    }

                    CategoryBadge(
                        name = item.category.name,
                        colorHex = item.category.colorHex
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "RECORDE PESSOAL (PR)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (prWeight > 0) "${prWeight.toInt()} kg" else "Nenhum",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "ÚLTIMA SESSÃO",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            val lastWeight = lastSession?.sets?.maxOfOrNull { it.weightKg } ?: 0f
                            val lastReps = lastSession?.sets?.maxByOrNull { it.weightKg }?.reps ?: 0
                            Text(
                                text = if (lastWeight > 0) "${lastWeight.toInt()} kg x $lastReps" else "Sem dados",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Histórico de Evolução de Carga",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                WeightEvolutionChart(dataPoints = chartPoints)

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        val exId = item.exercise.id
                        selectedExerciseForDetails = null
                        onStartWorkoutForExercise(exId)
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.FitnessCenter, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "INICIAR TREINO COM ESTE EXERCÍCIO",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Add Category Dialog
    if (showAddCategoryDialog) {
        var catName by remember { mutableStateOf("") }
        var selectedColorHex by remember { mutableStateOf("#FF5722") }

        AlertDialog(
            onDismissRequest = { showAddCategoryDialog = false },
            title = { Text("Nova Categoria (Grupo Muscular)") },
            text = {
                Column {
                    OutlinedTextField(
                        value = catName,
                        onValueChange = { catName = it },
                        label = { Text("Nome da Categoria (ex: Push, Costas)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Selecione uma cor para a badge:", fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(colorPresets) { hex ->
                            val color = Color(android.graphics.Color.parseColor(hex))
                            val isSelected = selectedColorHex == hex
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .then(
                                        if (isSelected) Modifier.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                        else Modifier
                                    )
                                    .clickable { selectedColorHex = hex }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (catName.isNotBlank()) {
                            onAddCategory(catName.trim(), selectedColorHex)
                            showAddCategoryDialog = false
                        }
                    }
                ) {
                    Text("Salvar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCategoryDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Manage Categories Dialog
    if (showManageCategoriesDialog) {
        AlertDialog(
            onDismissRequest = { showManageCategoriesDialog = false },
            title = { Text("Gerenciar Categorias") },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    categories.forEach { cat ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CategoryBadge(name = cat.name, colorHex = cat.colorHex)
                                }

                                Row {
                                    IconButton(
                                        onClick = { editingCategory = cat },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "Editar",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = { categoryToDelete = cat },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Excluir",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showManageCategoriesDialog = false }) {
                    Text("Concluído")
                }
            }
        )
    }

    // Edit Category Dialog
    editingCategory?.let { cat ->
        var catName by remember { mutableStateOf(cat.name) }
        var selectedColorHex by remember { mutableStateOf(cat.colorHex) }

        AlertDialog(
            onDismissRequest = { editingCategory = null },
            title = { Text("Editar Categoria") },
            text = {
                Column {
                    OutlinedTextField(
                        value = catName,
                        onValueChange = { catName = it },
                        label = { Text("Nome da Categoria") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Selecione a Cor:", fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(colorPresets) { hex ->
                            val color = Color(android.graphics.Color.parseColor(hex))
                            val isSelected = selectedColorHex == hex
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .then(
                                        if (isSelected) Modifier.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                        else Modifier
                                    )
                                    .clickable { selectedColorHex = hex }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (catName.isNotBlank()) {
                            onUpdateCategory(cat.copy(name = catName.trim(), colorHex = selectedColorHex))
                            editingCategory = null
                        }
                    }
                ) {
                    Text("Salvar")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingCategory = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Delete Category Modal (With Move Option)
    categoryToDelete?.let { cat ->
        val otherCategories = categories.filter { it.id != cat.id }
        var selectedTargetCatId by remember { mutableStateOf(otherCategories.firstOrNull()?.id) }
        var deleteMode by remember { mutableStateOf(if (otherCategories.isNotEmpty()) 0 else 1) } // 0 = Move exercises, 1 = Delete all

        AlertDialog(
            onDismissRequest = { categoryToDelete = null },
            title = { Text("Excluir Categoria '${cat.name}'") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Escolha o que fazer com os exercícios contidos nesta categoria:",
                        fontSize = 13.sp
                    )

                    if (otherCategories.isNotEmpty()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { deleteMode = 0 }
                        ) {
                            RadioButton(selected = deleteMode == 0, onClick = { deleteMode = 0 })
                            Text("Mover exercícios para outra categoria", fontSize = 13.sp)
                        }

                        if (deleteMode == 0) {
                            Text("Selecione a nova categoria:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(otherCategories) { targetCat ->
                                    FilterChip(
                                        selected = targetCat.id == selectedTargetCatId,
                                        onClick = { selectedTargetCatId = targetCat.id },
                                        label = { Text(targetCat.name) }
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { deleteMode = 1 }
                    ) {
                        RadioButton(selected = deleteMode == 1, onClick = { deleteMode = 1 })
                        Text("Excluir categoria e TODOS os exercícios dela", fontSize = 13.sp, color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val targetId = if (deleteMode == 0) selectedTargetCatId else null
                        onDeleteCategoryWithMove(cat, targetId)
                        categoryToDelete = null
                        showManageCategoriesDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Confirmar Exclusão")
                }
            },
            dismissButton = {
                TextButton(onClick = { categoryToDelete = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Add / Edit Exercise Dialog
    val currentExerciseToEdit = editingExercise
    if (showAddExerciseDialog || currentExerciseToEdit != null) {
        var exName by remember { mutableStateOf(currentExerciseToEdit?.name ?: "") }
        var targetMuscles by remember { mutableStateOf(currentExerciseToEdit?.targetMuscles ?: "") }
        var categoryId by remember { mutableStateOf(currentExerciseToEdit?.categoryId ?: categories.firstOrNull()?.id ?: 1L) }

        AlertDialog(
            onDismissRequest = {
                showAddExerciseDialog = false
                editingExercise = null
            },
            title = { Text(if (currentExerciseToEdit != null) "Editar Exercício" else "Novo Exercício") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = exName,
                        onValueChange = { exName = it },
                        label = { Text("Nome do Exercício (ex: Supino Inclinado)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = targetMuscles,
                        onValueChange = { targetMuscles = it },
                        label = { Text("Músculos Alvo (ex: Peito Superior, Tríceps)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Selecione a Categoria:", fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(categories) { cat ->
                            FilterChip(
                                selected = cat.id == categoryId,
                                onClick = { categoryId = cat.id },
                                label = { Text(cat.name) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (exName.isNotBlank()) {
                            if (currentExerciseToEdit != null) {
                                onUpdateExercise(
                                    currentExerciseToEdit.copy(
                                        name = exName.trim(),
                                        targetMuscles = targetMuscles.trim(),
                                        categoryId = categoryId
                                    )
                                )
                                editingExercise = null
                            } else {
                                onAddExercise(categoryId, exName.trim(), targetMuscles.trim())
                                showAddExerciseDialog = false
                            }
                        }
                    }
                ) {
                    Text("Salvar")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showAddExerciseDialog = false
                        editingExercise = null
                    }
                ) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Delete Exercise Confirmation Dialog
    exerciseToDeleteInfo?.let { (exercise, sessionCount) ->
        AlertDialog(
            onDismissRequest = { exerciseToDeleteInfo = null },
            title = { Text("Excluir Exercício?") },
            text = {
                Text(
                    text = if (sessionCount > 0) {
                        "Aviso: Este exercício '${exercise.name}' possui $sessionCount registro(s) de treino salvos no seu histórico. Se você excluí-lo, todos esses históricos serão apagados."
                    } else {
                        "Tem certeza que deseja excluir o exercício '${exercise.name}'?"
                    },
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteExercise(exercise)
                        exerciseToDeleteInfo = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Excluir")
                }
            },
            dismissButton = {
                TextButton(onClick = { exerciseToDeleteInfo = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun ExerciseListItem(
    exerciseWithCategory: ExerciseWithCategory,
    maxWeight: Float,
    lastSessionDate: Long?,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = exerciseWithCategory.exercise.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    CategoryBadge(
                        name = exerciseWithCategory.category.name,
                        colorHex = exerciseWithCategory.category.colorHex
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                val lastDateStr = if (lastSessionDate != null) {
                    "Último treino: " + SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(lastSessionDate))
                } else "Nenhum treino ainda"

                Text(
                    text = "$lastDateStr • Maior Carga: ${if (maxWeight > 0) "${maxWeight.toInt()} kg" else "-"}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            Box {
                IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Opções",
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Editar Exercício") },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        onClick = {
                            menuExpanded = false
                            onEdit()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Duplicar Exercício") },
                        leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        onClick = {
                            menuExpanded = false
                            onDuplicate()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Excluir Exercício", color = MaterialTheme.colorScheme.error) },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp)) },
                        onClick = {
                            menuExpanded = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}
