package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ExerciseWithCategory
import com.example.data.models.SessionWithDetails
import com.example.ui.components.CategoryBadge
import com.example.ui.components.ModernProgressBar
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

data class EditableSet(
    val setNumber: Int,
    var weightKg: Float,
    var reps: Int,
    var isCompleted: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutSessionScreen(
    exercises: List<ExerciseWithCategory>,
    sessions: List<SessionWithDetails>,
    initialExerciseId: Long?,
    onSaveSession: (
        exerciseId: Long,
        exerciseName: String,
        timestamp: Long,
        notes: String,
        tags: String,
        sets: List<Pair<Float, Int>>,
        autoStartTimer: Boolean,
        restSeconds: Int
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedExerciseId by remember(initialExerciseId, exercises) {
        mutableStateOf(initialExerciseId ?: exercises.firstOrNull()?.exercise?.id ?: 1L)
    }

    val selectedExercise = exercises.find { it.exercise.id == selectedExerciseId }

    // Last session data for intelligent suggestions & comparison
    val lastSession = remember(selectedExerciseId, sessions) {
        sessions
            .filter { it.session.exerciseId == selectedExerciseId }
            .maxByOrNull { it.session.timestamp }
    }

    var sets by remember(selectedExerciseId, lastSession) {
        mutableStateOf(
            if (lastSession != null && lastSession.sets.isNotEmpty()) {
                lastSession.sets.mapIndexed { idx, s ->
                    EditableSet(
                        setNumber = idx + 1,
                        weightKg = s.weightKg,
                        reps = s.reps,
                        isCompleted = false
                    )
                }.toMutableList()
            } else {
                mutableListOf(
                    EditableSet(setNumber = 1, weightKg = 40f, reps = 10),
                    EditableSet(setNumber = 2, weightKg = 40f, reps = 10),
                    EditableSet(setNumber = 3, weightKg = 40f, reps = 10)
                )
            }
        )
    }

    var selectedRestSeconds by remember { mutableStateOf(60) }
    var freeTextNotes by remember { mutableStateOf("") }
    var selectedTags by remember { mutableStateOf(setOf<String>()) }

    val availableTags = listOf(
        "Bom treino", "Fraco hoje", "Lesão/dor", "Bati PR", "Gás total", "Carga máxima", "Foco em execução"
    )

    var dropdownExpanded by remember { mutableStateOf(false) }
    var isSavingProcess by remember { mutableStateOf(false) }
    var saveProgressValue by remember { mutableStateOf<Float?>(null) }
    val coroutineScope = rememberCoroutineScope()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "REGISTRO DE TREINO",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )
            Text(
                text = "Nova Sessão",
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Exercise Selector Box
        item {
            ExposedDropdownMenuBox(
                expanded = dropdownExpanded,
                onExpandedChange = { dropdownExpanded = !dropdownExpanded }
            ) {
                OutlinedTextField(
                    value = selectedExercise?.exercise?.name ?: "Selecione o exercício",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Exercício") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )

                ExposedDropdownMenu(
                    expanded = dropdownExpanded,
                    onDismissRequest = { dropdownExpanded = false }
                ) {
                    exercises.forEach { ex ->
                        DropdownMenuItem(
                            text = {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(ex.exercise.name, fontWeight = FontWeight.Bold)
                                    CategoryBadge(name = ex.category.name, colorHex = ex.category.colorHex)
                                }
                            },
                            onClick = {
                                selectedExerciseId = ex.exercise.id
                                dropdownExpanded = false
                            }
                        )
                    }
                }
            }
        }

        // Intelligent Suggestion & Progression Banner
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = "Sugestão",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SUGESTÃO INTELIGENTE DE CARGA",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (lastSession != null && lastSession.sets.isNotEmpty()) {
                        val maxW = lastSession.sets.maxOfOrNull { it.weightKg } ?: 0f
                        val lastReps = lastSession.sets.maxByOrNull { it.weightKg }?.reps ?: 0

                        Text(
                            text = "Última sessão: ${maxW.toInt()} kg x $lastReps reps",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Ajuste rápido para todas as séries:",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(-5f, -2.5f, 2.5f, 5f).forEach { delta ->
                                OutlinedButton(
                                    onClick = {
                                        sets = sets.map { s ->
                                            s.copy(weightKg = (s.weightKg + delta).coerceAtLeast(0f))
                                        }.toMutableList()
                                    },
                                    shape = CircleShape,
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Text(
                                        text = if (delta > 0) "+${delta}kg" else "${delta}kg",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "Primeiro registro para este exercício! Escolha a carga inicial abaixo.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        // Sets Manager Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Séries (${sets.size})",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                // Rest Timer Config Dropdown
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = "Timer",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Descanso: ",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    listOf(30, 60, 90, 120).forEach { sec ->
                        Surface(
                            shape = CircleShape,
                            color = if (selectedRestSeconds == sec) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .padding(horizontal = 2.dp)
                                .size(28.dp)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(2.dp)
                            ) {
                                Text(
                                    text = "${sec}s",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedRestSeconds == sec) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // List of Sets
        itemsIndexed(sets) { index, setItem ->
            SetRowItem(
                set = setItem,
                onWeightChange = { newWeight ->
                    sets = sets.toMutableList().apply {
                        this[index] = this[index].copy(weightKg = newWeight)
                    }
                },
                onRepsChange = { newReps ->
                    sets = sets.toMutableList().apply {
                        this[index] = this[index].copy(reps = newReps)
                    }
                },
                onToggleComplete = {
                    val wasCompleted = sets[index].isCompleted
                    sets = sets.toMutableList().apply {
                        this[index] = this[index].copy(isCompleted = !wasCompleted)
                    }
                },
                onDelete = {
                    if (sets.size > 1) {
                        sets = sets.toMutableList().apply { removeAt(index) }
                    }
                }
            )
        }

        // Add Set Button
        item {
            OutlinedButton(
                onClick = {
                    val lastSet = sets.lastOrNull()
                    val nextNum = sets.size + 1
                    val nextWeight = lastSet?.weightKg ?: 40f
                    val nextReps = lastSet?.reps ?: 10
                    sets = (sets + EditableSet(setNumber = nextNum, weightKg = nextWeight, reps = nextReps)).toMutableList()
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Add, contentDescription = "Adicionar Série")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Adicionar Nova Série", fontWeight = FontWeight.Bold)
            }
        }

        // Tags Selection Section
        item {
            Column {
                Text(
                    text = "Tags de Desempenho",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    availableTags.take(4).forEach { tag ->
                        val isSelected = selectedTags.contains(tag)
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedTags = if (isSelected) selectedTags - tag else selectedTags + tag
                            },
                            label = { Text(tag, fontSize = 11.sp) }
                        )
                    }
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    availableTags.drop(4).forEach { tag ->
                        val isSelected = selectedTags.contains(tag)
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedTags = if (isSelected) selectedTags - tag else selectedTags + tag
                            },
                            label = { Text(tag, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }

        // Notes Input Section
        item {
            OutlinedTextField(
                value = freeTextNotes,
                onValueChange = { freeTextNotes = it },
                label = { Text("Notas do treino (opcional)") },
                placeholder = { Text("Ex: Senti bom bombeamento no peitoral, descanso ajustado...") },
                minLines = 2,
                maxLines = 4,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Finish & Save Session Button
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (isSavingProcess) {
                    Text(
                        text = "Salvando sessão de treino...",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    ModernProgressBar(
                        progress = saveProgressValue,
                        height = 8.dp,
                        showLabel = true
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Button(
                    onClick = {
                        if (selectedExercise != null && !isSavingProcess) {
                            isSavingProcess = true
                            coroutineScope.launch {
                                saveProgressValue = 0.2f
                                delay(120)
                                saveProgressValue = 0.6f
                                delay(150)
                                saveProgressValue = 1.0f
                                delay(150)

                                val setsData = sets.map { Pair(it.weightKg, it.reps) }
                                onSaveSession(
                                    selectedExercise.exercise.id,
                                    selectedExercise.exercise.name,
                                    System.currentTimeMillis(),
                                    freeTextNotes.trim(),
                                    selectedTags.joinToString(", "),
                                    setsData,
                                    true,
                                    selectedRestSeconds
                                )
                                isSavingProcess = false
                                saveProgressValue = null
                            }
                        }
                    },
                    enabled = !isSavingProcess,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = "Salvar")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSavingProcess) "SALVANDO..." else "FINALIZAR E SALVAR TREINO",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun SetRowItem(
    set: EditableSet,
    onWeightChange: (Float) -> Unit,
    onRepsChange: (Int) -> Unit,
    onToggleComplete: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (set.isCompleted) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Set Number Badge
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "${set.setNumber}",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontSize = 14.sp
                    )
                }
            }

            // Weight Control
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { onWeightChange((set.weightKg - 2.5f).coerceAtLeast(0f)) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "-2.5kg", modifier = Modifier.size(16.dp))
                }

                Text(
                    text = "${set.weightKg.toInt()} kg",
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )

                IconButton(
                    onClick = { onWeightChange(set.weightKg + 2.5f) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "+2.5kg", modifier = Modifier.size(16.dp))
                }
            }

            // Reps Control
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { onRepsChange((set.reps - 1).coerceAtLeast(1)) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "-1 rep", modifier = Modifier.size(16.dp))
                }

                Text(
                    text = "${set.reps} reps",
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )

                IconButton(
                    onClick = { onRepsChange(set.reps + 1) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "+1 rep", modifier = Modifier.size(16.dp))
                }
            }

            // Complete Checkbox & Delete
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onToggleComplete,
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            if (set.isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            CircleShape
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Concluir",
                        tint = if (set.isCompleted) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Excluir",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.6f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
