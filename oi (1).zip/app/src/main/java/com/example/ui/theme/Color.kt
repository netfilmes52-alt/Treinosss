package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FitLogPrimaryDark = Color(0xFFFF5722)
val FitLogPrimaryLight = Color(0xFFE64A19)

val FitLogBackgroundDark = Color(0xFF101116)
val FitLogSurfaceDark = Color(0xFF1B1D25)
val FitLogSurfaceVariantDark = Color(0xFF262936)

val FitLogBackgroundLight = Color(0xFFF8F9FE)
val FitLogSurfaceLight = Color(0xFFFFFFFF)
val FitLogSurfaceVariantLight = Color(0xFFEEF0F8)

val FitLogSecondaryDark = Color(0xFF2196F3)
val FitLogSecondaryLight = Color(0xFF1976D2)

