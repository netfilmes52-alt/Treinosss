package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = FitLogPrimaryDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF3E1E16),
    onPrimaryContainer = Color(0xFFFFCCBC),
    secondary = FitLogSecondaryDark,
    background = FitLogBackgroundDark,
    onBackground = Color(0xFFF0F1F5),
    surface = FitLogSurfaceDark,
    onSurface = Color(0xFFF0F1F5),
    surfaceVariant = FitLogSurfaceVariantDark,
    onSurfaceVariant = Color(0xFFC7C9D6)
)

private val LightColorScheme = lightColorScheme(
    primary = FitLogPrimaryLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFEBE5),
    onPrimaryContainer = Color(0xFF5C1B08),
    secondary = FitLogSecondaryLight,
    background = FitLogBackgroundLight,
    onBackground = Color(0xFF191B23),
    surface = FitLogSurfaceLight,
    onSurface = Color(0xFF191B23),
    surfaceVariant = FitLogSurfaceVariantLight,
    onSurfaceVariant = Color(0xFF434656)
)

@Composable
fun FitLogTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

