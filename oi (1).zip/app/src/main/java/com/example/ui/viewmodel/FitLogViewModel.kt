package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiRepository
import com.example.data.database.FitLogDatabase
import com.example.data.models.CategoryEntity
import com.example.data.models.ExerciseEntity
import com.example.data.models.ExerciseWithCategory
import com.example.data.models.SessionWithDetails
import com.example.data.models.WorkoutSessionEntity
import com.example.data.repository.FitLogRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Date

data class GeminiChatMessage(
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

sealed class LastDeletedItem {
    data class CategoryItem(val category: CategoryEntity) : LastDeletedItem()
    data class ExerciseItem(val exercise: ExerciseEntity) : LastDeletedItem()
    data class SessionItem(val sessionWithDetails: SessionWithDetails) : LastDeletedItem()
}

class FitLogViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FitLogRepository
    private val geminiRepository = GeminiRepository()

    val allCategories: StateFlow<List<CategoryEntity>>
    val allExercises: StateFlow<List<ExerciseWithCategory>>
    val allSessions: StateFlow<List<SessionWithDetails>>

    // Gemini Chat State
    private val _chatMessages = MutableStateFlow<List<GeminiChatMessage>>(
        listOf(
            GeminiChatMessage(
                isUser = false,
                text = "Olá! Eu sou o Gemini Coach 🤖🏋️‍♂️. Posso te dar dicas de execução, sugestões de treino, ajustar suas cargas, tirar dúvidas de nutrição e analisar sua evolução. Como posso te ajudar hoje?"
            )
        )
    )
    val chatMessages: StateFlow<List<GeminiChatMessage>> = _chatMessages.asStateFlow()

    private val _isGeminiLoading = MutableStateFlow(false)
    val isGeminiLoading: StateFlow<Boolean> = _isGeminiLoading.asStateFlow()

    // Dark Mode Theme toggle
    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Rest Timer state
    private val _restTimerSeconds = MutableStateFlow(0)
    val restTimerSeconds: StateFlow<Int> = _restTimerSeconds.asStateFlow()

    private val _restTimerInitialSeconds = MutableStateFlow(60)
    val restTimerInitialSeconds: StateFlow<Int> = _restTimerInitialSeconds.asStateFlow()

    private val _isRestTimerRunning = MutableStateFlow(false)
    val isRestTimerRunning: StateFlow<Boolean> = _isRestTimerRunning.asStateFlow()

    private val _restTimerFinishedEvent = MutableStateFlow(false)
    val restTimerFinishedEvent: StateFlow<Boolean> = _restTimerFinishedEvent.asStateFlow()

    private var timerJob: Job? = null

    // PR Celebration state
    private val _latestPRNotification = MutableStateFlow<String?>(null)
    val latestPRNotification: StateFlow<String?> = _latestPRNotification.asStateFlow()

    // Undo Banner state
    private val _undoMessage = MutableStateFlow<String?>(null)
    val undoMessage: StateFlow<String?> = _undoMessage.asStateFlow()

    private var lastDeletedItem: LastDeletedItem? = null

    init {
        val database = FitLogDatabase.getDatabase(application)
        repository = FitLogRepository(database.fitLogDao())

        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }

        allCategories = repository.allCategories.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allExercises = repository.allExercises.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allSessions = repository.allSessions.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    // --- GEMINI AI ASSISTANT ACTIONS ---
    fun sendGeminiQuery(query: String) {
        if (query.isBlank() || _isGeminiLoading.value) return

        val userMsg = GeminiChatMessage(isUser = true, text = query)
        _chatMessages.value = _chatMessages.value + userMsg
        _isGeminiLoading.value = true

        viewModelScope.launch {
            val exercises = allExercises.value
            val sessions = allSessions.value

            val userContext = "Exercícios no catálogo: ${exercises.map { it.exercise.name }.take(10).joinToString(", ")}. Total de sessões salvas: ${sessions.size}."

            val aiResponse = geminiRepository.generateFitnessAdvice(query, userContext)
            _chatMessages.value = _chatMessages.value + GeminiChatMessage(isUser = false, text = aiResponse)
            _isGeminiLoading.value = false
        }
    }

    fun analyzeProgressWithGemini() {
        if (_isGeminiLoading.value) return

        val promptUser = "Analise meu progresso de treinos registrado no FitLog e me dê recomendações personalizadas."
        val userMsg = GeminiChatMessage(isUser = true, text = promptUser)
        _chatMessages.value = _chatMessages.value + userMsg
        _isGeminiLoading.value = true

        viewModelScope.launch {
            val aiResponse = geminiRepository.analyzeProgressAndSuggest(allExercises.value, allSessions.value)
            _chatMessages.value = _chatMessages.value + GeminiChatMessage(isUser = false, text = aiResponse)
            _isGeminiLoading.value = false
        }
    }

    fun clearChatHistory() {
        _chatMessages.value = listOf(
            GeminiChatMessage(
                isUser = false,
                text = "Histórico limpo! Como posso ajudar em seu próximo treino?"
            )
        )
    }


    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun dismissPRNotification() {
        _latestPRNotification.value = null
    }

    // --- REST TIMER CONTROLS ---
    fun startRestTimer(seconds: Int) {
        timerJob?.cancel()
        _restTimerInitialSeconds.value = seconds
        _restTimerSeconds.value = seconds
        _isRestTimerRunning.value = true
        _restTimerFinishedEvent.value = false

        timerJob = viewModelScope.launch {
            while (_restTimerSeconds.value > 0 && _isRestTimerRunning.value) {
                delay(1000L)
                _restTimerSeconds.value -= 1
            }
            if (_restTimerSeconds.value <= 0) {
                _isRestTimerRunning.value = false
                _restTimerFinishedEvent.value = true
            }
        }
    }

    fun pauseRestTimer() {
        _isRestTimerRunning.value = false
        timerJob?.cancel()
    }

    fun resumeRestTimer() {
        if (_restTimerSeconds.value > 0) {
            _isRestTimerRunning.value = true
            timerJob = viewModelScope.launch {
                while (_restTimerSeconds.value > 0 && _isRestTimerRunning.value) {
                    delay(1000L)
                    _restTimerSeconds.value -= 1
                }
                if (_restTimerSeconds.value <= 0) {
                    _isRestTimerRunning.value = false
                    _restTimerFinishedEvent.value = true
                }
            }
        }
    }

    fun addRestTime(additionalSeconds: Int) {
        _restTimerSeconds.value += additionalSeconds
    }

    fun stopRestTimer() {
        timerJob?.cancel()
        _restTimerSeconds.value = 0
        _isRestTimerRunning.value = false
        _restTimerFinishedEvent.value = false
    }

    fun dismissTimerFinishedEvent() {
        _restTimerFinishedEvent.value = false
    }

    // --- DATABASE ACTIONS ---
    fun saveWorkoutSession(
        exerciseId: Long,
        exerciseName: String,
        timestamp: Long,
        notes: String,
        tags: String,
        sets: List<Pair<Float, Int>>,
        autoStartTimer: Boolean = true,
        restSeconds: Int = 60
    ) {
        viewModelScope.launch {
            val sessionId = repository.saveWorkoutSession(
                exerciseId = exerciseId,
                timestamp = timestamp,
                notes = notes,
                tags = tags,
                sets = sets
            )

            // Check if PR was set
            val sessions = allSessions.value
            val currentMaxWeight = sets.maxOfOrNull { it.first } ?: 0f
            val previousMax = sessions
                .filter { it.session.exerciseId == exerciseId && it.session.id != sessionId }
                .flatMap { it.sets }
                .maxOfOrNull { it.weightKg } ?: 0f

            if (currentMaxWeight > 0f && currentMaxWeight > previousMax) {
                _latestPRNotification.value = "🎉 NOVO RECORDE PESSOAL em $exerciseName: ${currentMaxWeight.toInt()} kg!"
            }

            if (autoStartTimer && restSeconds > 0) {
                startRestTimer(restSeconds)
            }
        }
    }

    // --- DATABASE & DATA MANAGEMENT ACTIONS ---
    fun addCategory(name: String, colorHex: String, iconName: String) {
        viewModelScope.launch {
            repository.insertCategory(CategoryEntity(name = name, colorHex = colorHex, iconName = iconName))
        }
    }

    fun updateCategory(category: CategoryEntity) {
        viewModelScope.launch {
            repository.updateCategory(category)
        }
    }

    fun deleteCategory(category: CategoryEntity, targetCategoryId: Long? = null) {
        viewModelScope.launch {
            lastDeletedItem = LastDeletedItem.CategoryItem(category)
            repository.deleteCategoryAndMoveExercises(category, targetCategoryId)
            _undoMessage.value = "Categoria '${category.name}' excluída"
        }
    }

    fun addExercise(categoryId: Long, name: String, targetMuscles: String) {
        viewModelScope.launch {
            repository.insertExercise(
                ExerciseEntity(
                    categoryId = categoryId,
                    name = name,
                    targetMuscles = targetMuscles
                )
            )
        }
    }

    fun updateExercise(exercise: ExerciseEntity) {
        viewModelScope.launch {
            repository.updateExercise(exercise)
        }
    }

    fun duplicateExercise(exercise: ExerciseEntity) {
        viewModelScope.launch {
            repository.duplicateExercise(exercise)
        }
    }

    fun deleteExercise(exercise: ExerciseEntity) {
        viewModelScope.launch {
            lastDeletedItem = LastDeletedItem.ExerciseItem(exercise)
            repository.deleteExercise(exercise)
            _undoMessage.value = "Exercício '${exercise.name}' excluído"
        }
    }

    fun getSessionsCountForExercise(exerciseId: Long, onResult: (Int) -> Unit) {
        viewModelScope.launch {
            val count = repository.getSessionsCountForExercise(exerciseId)
            onResult(count)
        }
    }

    fun updateSessionAndSets(
        sessionId: Long,
        exerciseId: Long,
        timestamp: Long,
        notes: String,
        tags: String,
        sets: List<Pair<Float, Int>>
    ) {
        viewModelScope.launch {
            repository.updateSessionAndSets(
                sessionId = sessionId,
                exerciseId = exerciseId,
                timestamp = timestamp,
                notes = notes,
                tags = tags,
                sets = sets
            )
        }
    }

    fun duplicateSession(sessionWithDetails: SessionWithDetails) {
        viewModelScope.launch {
            repository.duplicateSession(sessionWithDetails)
        }
    }

    fun deleteSession(sessionWithDetails: SessionWithDetails) {
        viewModelScope.launch {
            lastDeletedItem = LastDeletedItem.SessionItem(sessionWithDetails)
            repository.deleteSession(sessionWithDetails.session)
            _undoMessage.value = "Registro de treino excluído"
        }
    }

    fun undoLastDeletion() {
        val itemToUndo = lastDeletedItem ?: return
        viewModelScope.launch {
            when (itemToUndo) {
                is LastDeletedItem.CategoryItem -> repository.restoreCategory(itemToUndo.category)
                is LastDeletedItem.ExerciseItem -> repository.restoreExercise(itemToUndo.exercise)
                is LastDeletedItem.SessionItem -> repository.restoreSession(
                    itemToUndo.sessionWithDetails.session,
                    itemToUndo.sessionWithDetails.sets
                )
            }
            lastDeletedItem = null
            _undoMessage.value = "Item restaurado com sucesso!"
            delay(2000)
            if (_undoMessage.value == "Item restaurado com sucesso!") {
                _undoMessage.value = null
            }
        }
    }

    fun dismissUndoMessage() {
        _undoMessage.value = null
    }

    // Backup
    fun exportBackup(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val json = repository.exportToJson()
            onResult(json)
        }
    }

    fun importBackup(jsonString: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = repository.importFromJson(jsonString)
            onResult(success)
        }
    }
}
